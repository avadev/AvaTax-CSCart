<?php

	include_once($lib_path."AvaTax4PHP/AvaTax.php");
	spl_autoload_register(__autoload);
	
	$successMsg = "";
	$development_url = $_REQUEST["serviceurl"];
	$account = $_REQUEST["acc"];
	$license = $_REQUEST["license"];
	$environment = $_REQUEST["environment"];
	$client = $_REQUEST["client"];
	
	new ATConfig($environment, array('url'=>$development_url, 'account'=>$account,'license'=>$license,'client'=>$client, 'trace'=> TRUE));

	$client = new TaxServiceSoap($environment);

	try
	{
		$result = $client->isAuthorized("");
		
		if($result->getResultCode() != SeverityLevel::$Success)	// call failed
		{
			foreach($result->Messages() as $msg)
			{					
				$successMsg .= $msg->Name().": ".$msg->Summary()."<br/>\n";
			}

		} 
		else // successful calll
		{
            $dateTime = new DateTime();
            $dateTime = strtotime($result->getExpires());
            $dateTime = date ("Y-m-d", $dateTime);
            $successMsg .= "Welcome to the AvaTax Service.<br/>";
            $successMsg .= "Connection Test Status: <span style='color:green;'>".$result->getResultCode()."</span><br/>";
            $successMsg .= "Account Expiry Date : <span style='color:green;'>".$dateTime."</span><br/>";
		}
		echo "<div style='text-align:center;padding-top:10px;'>".$successMsg."</div>";
	}
	catch(SoapFault $exception)
	{
		$msg = "Reason: ";
		if($exception)
			$msg .= $exception->faultstring;

		$successMsg .= "Welcome to the Ava Tax Service.<br/>";
		$successMsg .= "Connection Test Status: <span style='color:red;'>Failed</span><br/>";
			
		$successMsg .= $msg."<br/>";
		//$successMsg .= $client->__getLastRequest()."<br/>";
		//$successMsg .= $client->__getLastResponse()."<br/>";
		echo "<div style='text-align:center;padding-top:10px;'>".$successMsg."</div>"; 
	}	
?>