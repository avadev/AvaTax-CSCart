REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(6, 'Nokia n1', '', '', 'en');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(7, 'Gift certificate', 'gift_certificates.add', '', 'en');
REPLACE INTO ?:banner_descriptions (`banner_id`, `banner`, `url`, `description`, `lang_code`) VALUES(8, 'Holiday gift guide', 'gift_certificates.add', '', 'en');

REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(14, 6, 'en');
REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(16, 7, 'en');
REPLACE INTO ?:banner_images (`banner_image_id`, `banner_id`, `lang_code`) VALUES(18, 8, 'en');