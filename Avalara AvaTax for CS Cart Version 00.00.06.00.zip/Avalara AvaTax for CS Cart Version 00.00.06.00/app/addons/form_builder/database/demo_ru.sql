REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('1', 'Ваше имя', 'ru');
REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('2', 'Email', 'ru');
REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('3', 'Сообщение', 'ru');
REPLACE INTO ?:form_descriptions (`object_id`, `description`, `lang_code`) VALUES ('4', 'Благодарим вас за обращение к нам. Мы ответим вам при первой же возможности.', 'ru');