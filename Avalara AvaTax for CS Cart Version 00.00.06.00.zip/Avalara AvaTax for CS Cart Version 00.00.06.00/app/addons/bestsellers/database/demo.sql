REPLACE INTO ?:product_sales (category_id, product_id, amount) VALUES ('221', '44', '1');
REPLACE INTO ?:product_sales (category_id, product_id, amount) VALUES ('221', '45', '1');
REPLACE INTO ?:product_sales (category_id, product_id, amount) VALUES ('221', '46', '1');
REPLACE INTO ?:product_sales (category_id, product_id, amount) VALUES ('236', '67', '0');
REPLACE INTO ?:product_sales (category_id, product_id, amount) VALUES ('236', '68', '0');