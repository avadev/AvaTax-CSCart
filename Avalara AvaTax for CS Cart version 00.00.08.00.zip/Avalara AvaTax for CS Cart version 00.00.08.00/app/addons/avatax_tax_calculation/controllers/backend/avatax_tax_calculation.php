<?php
/***************************************************************************
*                                                                          *
*   (c) 2004 Vladimir V. Kalynyak, Alexey V. Vinokurov, Ilya M. Shalnev    *
*                                                                          *
* This  is  commercial  software,  only  users  who have purchased a valid *
* license  and  accept  to the terms of the  License Agreement can install *
* and use this program.                                                    *
*                                                                          *
****************************************************************************
* PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
* "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
****************************************************************************/

use Tygh\Registry;

if (!defined('BOOTSTRAP')) { die('Access denied'); }

if ($mode == 'connection_test') {
   
	$lib_path = Registry::get('config.dir.addons') . 'avatax_tax_calculation/lib/';
    $addon_path = Registry::get('config.dir.addons') . 'avatax_tax_calculation';
    $log_mode = Registry::get('addons.avatax_tax_calculation.avatax_log_mode');
	require_once($lib_path."AvaTax4PHP/avatax_test_connection.php");	
	exit;
}
if ($mode == 'setup_assistant') {
   
	$lib_path = Registry::get('config.dir.addons') . 'avatax_tax_calculation/lib/';
    $addon_path = Registry::get('config.dir.addons') . 'avatax_tax_calculation';
    $log_mode = Registry::get('addons.avatax_tax_calculation.avatax_log_mode');
    
	require_once($lib_path."AvaTax4PHP/avatax_accounts.php");
        
        if(isset($_REQUEST["from"]) && $_REQUEST["from"]=="AvaTaxFetchCompanies"){

       
	AccountValidation(); 
}
	exit;
}